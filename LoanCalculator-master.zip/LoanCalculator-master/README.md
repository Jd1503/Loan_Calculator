# LoanCalculator
A simple loan calculator app
